//��ʵ�����еĳ���ģ����C����ʵ��
/*��1���˵���ʾ
  ��2����Ʒ��ѯ
  ��5�����ȫ����Ʒ��Ϣ
*/
extern  void  DISPLAY_INF(void);
extern  void  RESET(void);
extern  void  F3(void);
extern  void  F4(void);
extern  void  EXIT(void);
extern  char GA1;
extern  char RETURN;

#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int AUTH;
//�˵���ʾ
int menu_1()
{
    int i,k;
    while(1)
    {
        system("cls");
		printf(" ----------------------  MENU  ----------------------- \n");
		printf(" |        1 = QUERY PRODUCT INFORMATION               | \n");
        printf(" |        2 = RESET PRODUCT INFORMATION               | \n");
		printf(" |        3 = CALCULATE RECOMMENDATION RATE           | \n");
		printf(" |        4 = CALCULATE RECOMMENDATION RANKS          | \n");
		printf(" |        5 = OUTPUT ALL PRODUCT INFORMATION          | \n");
		printf(" |        6 = EXIT                                    | \n");
		printf(" |                                                    | \n");
		printf(" ----------------------------------------------------- \n");
		printf("Please input the number:                               \n");

    scanf("%d",&i);
    switch(i)
    {
        case 1:
               DISPLAY_INF();//��Ʒ��Ϣ��ѯ,�û��ϰ�Կ�
               getchar();
               getchar();
               break;
        case 2:
               if(AUTH == 1){
                    RESET();
                    if(RETURN == 0)//��ʾû���޸�
                        break;
               }
               else{
                    printf("INVALID INPUT");
               }
               getchar();
               getchar();
               break;
        case 3:
               if(AUTH == 1)
                    F3();
               else{
                    printf("INVALID INPUT");
               }
               getchar();
               getchar();
               break;
        case 4:
               if(AUTH == 1)
                    F4();
               else{
                    printf("INVALID INPUT");
               }
               getchar();
               getchar();
               break;
        case 5:
               if(AUTH == 1)
                    PUTOUT();
               else{
                    printf("INVALID INPUT");
               }
               getchar();
               getchar();
               break;
        case 6:
               EXIT();
               return 0;
        default:
               printf("INVALID INPUT!");
               break;
    }
    }
}

int menu_2()
{
    int i;
    while(1)
    {
        system("cls");
		printf(" ----------------------  MENU  ----------------------- \n");
		printf(" |        1 = QUERY PRODUCT INFORMATION               | \n");
		printf(" |        6 = EXIT                                    | \n");
		printf(" |                                                    | \n");
		printf(" ----------------------------------------------------- \n");
		printf("Please input the number:                               \n");

    scanf("%d",&i);
    switch(i)
    {
        case 1:
               DISPLAY_INF();
               getchar();
               getchar();
               break;
        case 6:
               EXIT();
               return 0;
        default:
               printf("INVALID INPUT!");
               break;
    }
    }
}

int PUTOUT()//���������Ʒ����Ϣ
{
    int i;/*������*/
	short *n;
	char *DATA=&GA1;
	printf("       TRADE         IN_P       OUT_P      IN_N       SALE_N       PTR\n");
	for(i = 0;i < 6;i++)
	{
		n = DATA + 11;
		printf(" %10s : %10hd %10hd %10hd %10hd %10hd\n",DATA,*n,*(n+1),*(n+2),*(n+3),*(n+4));
        DATA += 21;
	}
}

//��¼��֤������0Ϊ��¼���󣬷���1Ϊ��¼�ɹ�������2Ϊ�û�,����3Ϊֱ���˳�
int judge_n(char *s,char *p)
{
    int i = 0;
    char name[10];
    char password[6];
    printf("PLEASE INPUT YOUR NAME:");
    scanf("%s",name,10);
    if(name[0] == '#'){//�ж�Ϊ�û�
            AUTH = 0;
            return 2;
    }
    if(strcmp(name,"q") ==0 )
        return 3;
    printf("PLEASE INPUT YOUR PASSPWORD:");
    scanf("%s",password,6);
    if(strcmp(name,s) == 0){
        if(strcmp(password,p) == 0)
            AUTH = 0;
            i = 1;
    }
    if(i == 1){
        printf("LOGIN SUCCESSFULLY!\n");
        AUTH = 1;
        return 1;
    }
    else{
        printf("LOGIN FAILED!\n");
        return 0;
    }
}



int main()
{
    int m = 0;
    char B_name[] = {"Somnus"};
    char B_pass[] = {"66666"};
    char name[10];
    while(!m){//����¼ʧ��ʱ�ٴε�¼
        m = judge_n(B_name,B_pass);//�жϵ�¼�Ƿ�ɹ�
    }
    if(m == 1){
        menu_1();
    }
    if(m == 2){
        menu_2();
    }
    if(m == 3)
        return 0;
}
